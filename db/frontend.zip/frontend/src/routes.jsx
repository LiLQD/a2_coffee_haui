import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import HomePage from "./pages/HomePage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import CartPage from "./pages/CartPage.jsx";

function AppRoutes() {
  return (
    <Routes>
      {/* Home sau khi login */}
      <Route path="/home" element={<HomePage />} />
      {/* Trang đầu là login */}
      <Route path="/" element={<LoginPage />} />

    
      <Route path="/cart" element={<CartPage />} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default AppRoutes;
